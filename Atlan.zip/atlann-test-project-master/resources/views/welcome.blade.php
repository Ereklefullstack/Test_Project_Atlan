@extends('layouts.app')

@section('content')
    <div class="container">
        <div class="display-1 pt-5">
            <div class="text-center pt-5">
                <i class="fas fa-tasks text-info"></i>
                Project For Test
            </div>
        </div>
    </div>
@endsection
